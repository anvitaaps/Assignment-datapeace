export const navigation = [
    {
        'id'   : 'users',
        'title': 'Users',
        'type' : 'item',
        'icon' : 'icon-account-box',
        'url'  : '/apps/users',
        // 'roleId' : [1]
    }
];
