import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { FuseSharedModule } from '@fuse/shared.module';
import { FormControl } from '@angular/forms';
import { environment } from 'environments/environment';
import { AuthGuard } from 'app/auth.guard';


const routes = [
    {
        path        : 'users',
        loadChildren : './users/users.module#UsersModule',
        // canActivate: [AuthGuard]
    }
];

@NgModule({
    imports     : [
        FuseSharedModule,
        RouterModule.forChild(routes)
    ],
    declarations: []
})
export class FuseAppsModule
{
    public static API_ENDPOINT=environment.api_endpoint; //dev server
    // public static API_ENDPOINT='http://emd.thelattice.org:8091'; //test
    
    //Function to check form do not accepts white spaces as non-empty value
    public static noWhitespaceValidator(control: FormControl) {
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true }
  }

  //Email validation
  public static mailFormat(control: FormControl)
    {
        const EMAIL_REGEXP = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

        if (control.value && !EMAIL_REGEXP.test(control.value))
        {
            return {
                validateEmail: {
                    valid: false,
                    message: "Not valid email."
                }
            };
        }

        return null;
    }

    //Validation for password containg atleast one lowercase, one uppercase and one number
    public static strong(control: FormControl) {
        let hasNumber = /\d/.test(control.value);
        let hasUpper = /[A-Z]/.test(control.value);
        let hasLower = /[a-z]/.test(control.value);
        // console.log('Num, Upp, Low', hasNumber, hasUpper, hasLower);
        const valid = hasNumber && hasUpper && hasLower;
        if (!valid) {
            // return what´s not valid
            return { strong: true };
        }
        return null;
    }

    //Function to convert milliseconds to time HH:MM
    public static millisecondsToTime(millisecond) {
        // console.log(millisecond.getHours(), millisecond.getMinutes())
        let time: any = new Date(millisecond);
        let hours: any = time.getHours();
        let minutes = time.getMinutes();
  
        hours = (hours < 10) ? "0" + hours : hours;
        minutes = (minutes < 10) ? "0" + minutes : minutes;
        return( hours + ":" + minutes );
      }
}
