export const environment = {
    test:   false,
    production: true,
    hmr       : false,
    api_endpoint    :   'https://emddev.thelattice.org/adminwebservice'
};
