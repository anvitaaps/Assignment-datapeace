export const environment = {
    test    :   false,
    production: false,
    hmr       : true,
    api_endpoint    :   'http://demo9197058.mockable.io'
};
