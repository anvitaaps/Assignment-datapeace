export const environment = {
    test:   true,
    production: false,
    hmr       : false,
    api_endpoint    :   'https://emddev.thelattice.org/adminwebservice'
};
