Steps to setup Angular Application on local system

Install nodejs using the below link. 'https://nodejs.org/en/download/'

Open command prompt (CMD)

Install angular cli : 'npm install -g @angular/cli'

Change the current directory to application folder : cd (full path of your frontend folder).

Install all dependencies : 'npm install'

Run application : 'ng serve' By default it will serve on port '4200'. Open browser and access link : 'localhost:4200' If you want to run your application on any other port, use the following command : 'ng serve --port 4401'. Now your application can be accessed from port 4401.